package collect;

public interface Iterat {
public boolean hasnext();
public Object next();
public void remove();
}
