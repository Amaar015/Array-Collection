package collect;

public interface collect {
public boolean add(Object obj);
public void clear();
public boolean contains(Object obj);
public boolean Isempty();
public Iterat iterat();
public boolean remove(Object obj);
public int size();

}
